import sys
import importlib

def main():
	print(importlib.metadata.version('lmdemo'))

if __name__ == '__main__':
	sys.exit(main())