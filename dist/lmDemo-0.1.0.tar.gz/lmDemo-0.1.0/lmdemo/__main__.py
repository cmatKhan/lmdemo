import sys
from importlib.metadata import version 

def main():
	print(version('lmdemo'))

sys.exit(main())
